/*
 * logic.h
 *
 *  Created on: Jun 21, 2021
 *      Author: tobias
 */

#ifndef INC_LOGIC_H_
#define INC_LOGIC_H_

uint32_t xor32(void);
void conway( uint8_t* p , uint8_t* f);


#endif /* INC_LOGIC_H_ */
